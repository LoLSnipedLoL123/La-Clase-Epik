# La Clase Epik v3

Private Expo app for up to 50 friends. v3 adds the features discussed for the next production pass:

- Supabase Auth + persistent sessions
- Automatic member discovery / feed connection
- Real-time messages and presence
- Message reactions, editing and deletion
- Read receipts
- Typing indicators
- Image/video message picker + Supabase Storage
- 24-hour stories with optional media
- Push notification token registration
- Profile bio/avatar URL fields
- Search users
- Groups foundation (database + API)
- Owner/admin/moderator role foundation
- Windows XP / Pikochat / Custom themes
- HEX background and font-size overrides
- Local AsyncStorage fallback when Supabase credentials are blank
- 50-user database cap
- RLS and private Realtime channel policies

## Backend setup

1. Create a Supabase project.
2. Run `supabase/schema.sql` in SQL Editor.
3. Create a **public Storage bucket named `media`** if you want image/video messages. For a private server, replace the public bucket with signed URLs and matching Storage RLS before sharing sensitive media.
4. Copy the Project URL and Publishable key into `.env` using `.env.example`.
5. `npm install`
6. `npx expo start`

Never put a Supabase `service_role` secret in this app.

## Realtime

Supabase stores the rows in Postgres and broadcasts changes through Realtime. The client subscribes to `messages`, `profiles`, `typing_status`, and `message_reads` and refreshes the relevant state immediately.

## Push notifications

The app registers an Expo push token on physical devices. This v3 client stores the token in `push_tokens`. Sending actual push notifications should be done from a trusted Edge Function/server using a server-side secret; do not send them from the mobile client.

## Important production notes

- Username/password is currently implemented through an internal deterministic email identity. A future hardening step is to move username lookup into an Edge Function.
- For truly private media, use a private Storage bucket and signed URLs instead of public URLs.
- Admin role changes need a server-side function/RPC that verifies the caller is an owner/admin. Do not expose unrestricted role updates to clients.
- Test RLS policies in Supabase before inviting all 50 users.
