import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import Avatar from "./Avatar";

export default function MessageBubble({ message, currentUserId, theme, onReaction }) {
  const mine = message.sender_id === currentUserId;
  return (
    <View style={[styles.row, mine && styles.rowMine]}>
      {!mine && <Avatar user={{ username: message.sender_username, avatar: message.sender_avatar, presence: message.presence || "Online" }} size={42} />}
      <View style={[styles.content, mine && styles.contentMine]}>
        {!mine && <Text style={[styles.username, { color: theme.text }]}>{message.sender_username}</Text>}
        <View style={[styles.bubble, { backgroundColor: mine ? theme.bubbleMe : theme.bubbleOther, borderRadius: theme.radius }]}>
          <Text style={[styles.message, { color: mine ? "#FFFFFF" : theme.text, fontSize: theme.fontSize }]}>{message.content}</Text>
        </View>
        <View style={styles.reactions}>
          {["❤️", "😂", "🔥"].map((emoji) => {
            const count = message.reactions?.[emoji] || 0;
            return (
              <TouchableOpacity key={emoji} onPress={() => onReaction(message.id, emoji)} style={[styles.reaction, { backgroundColor: theme.surface2, borderColor: theme.border }]}>
                <Text>{emoji}</Text>{count > 0 && <Text style={{ color: theme.muted, marginLeft: 3, fontSize: 11 }}>{count}</Text>}
              </TouchableOpacity>
            );
          })}
        </View>
      </View>
      {mine && <Avatar user={{ avatar: message.sender_avatar, presence: "Online" }} size={42} />}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "flex-start", paddingHorizontal: 12, marginVertical: 7 },
  rowMine: { justifyContent: "flex-end" },
  content: { maxWidth: "76%", marginLeft: 9 },
  contentMine: { marginLeft: 0, marginRight: 9, alignItems: "flex-end" },
  username: { fontWeight: "900", fontSize: 13, marginBottom: 4 },
  bubble: { paddingHorizontal: 13, paddingVertical: 10 },
  message: { lineHeight: 21 },
  reactions: { flexDirection: "row", marginTop: 5 },
  reaction: { flexDirection: "row", paddingHorizontal: 7, paddingVertical: 4, marginRight: 4, borderWidth: 1, borderRadius: 12 },
});
