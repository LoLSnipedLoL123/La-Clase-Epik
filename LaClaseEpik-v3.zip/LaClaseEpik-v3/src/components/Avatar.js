import React from "react";
import { View, Text, StyleSheet } from "react-native";

const PRESENCE_COLORS = { Online: "#42E06F", Idle: "#F4C542", DND: "#F04444", Invisible: "#777777" };

export default function Avatar({ user, size = 48 }) {
  const presence = user?.presence || "Invisible";
  return (
    <View style={[styles.container, { width: size, height: size, borderRadius: size / 2 }]}>
      <Text style={[styles.avatar, { fontSize: size * 0.48 }]}>{user?.avatar || "🙂"}</Text>
      <View style={[styles.badge, { backgroundColor: PRESENCE_COLORS[presence] }]} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { justifyContent: "center", alignItems: "center", position: "relative" },
  avatar: { textAlign: "center" },
  badge: { position: "absolute", bottom: 1, right: 1, width: 13, height: 13, borderRadius: 7, borderWidth: 2, borderColor: "#FFFFFF" },
});
