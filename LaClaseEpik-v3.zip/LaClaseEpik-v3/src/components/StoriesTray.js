import React, { useEffect, useRef, useState } from "react";
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Animated } from "react-native";
import Avatar from "./Avatar";

export default function StoriesTray({ stories, theme, onStoryPress }) {
  const [visible, setVisible] = useState(true);
  const opacity = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    setVisible(true); opacity.setValue(1);
    const timer = setTimeout(() => {
      Animated.timing(opacity, { toValue: 0, duration: 500, useNativeDriver: true }).start(() => setVisible(false));
    }, 9000);
    return () => clearTimeout(timer);
  }, [stories]);

  if (!visible || !stories?.length) return null;

  return (
    <Animated.View style={[styles.container, { opacity, backgroundColor: theme.surface, borderBottomColor: theme.border }]}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        {stories.map((story) => (
          <TouchableOpacity key={story.id} onPress={() => onStoryPress?.(story)} style={styles.story}>
            <View style={[styles.ring, { borderColor: theme.primary }]}><Avatar user={story} size={52} /></View>
            <Text numberOfLines={1} style={[styles.username, { color: theme.text }]}>{story.username}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: { borderBottomWidth: 1 },
  scrollContent: { paddingHorizontal: 12, paddingVertical: 10 },
  story: { width: 72, alignItems: "center", marginRight: 8 },
  ring: { borderWidth: 2, borderRadius: 32, padding: 2 },
  username: { marginTop: 5, fontSize: 11, fontWeight: "700", maxWidth: 68 },
});
