export const THEMES = {
  xp: {
    name: "Windows XP", background: "#C0C0C0", surface: "#ECE9D8", surface2: "#FFFFFF",
    text: "#000000", muted: "#555555", primary: "#245EDB", secondary: "#3A81F6",
    border: "#7F7F7F", header: "#245EDB", bubbleMe: "#D7E8FF", bubbleOther: "#FFFFFF",
    input: "#FFFFFF", radius: 4, fontSize: 15, shadow: true,
  },
  pikochat: {
    name: "Pikochat", background: "#0C0C12", surface: "#15151F", surface2: "#20202D",
    text: "#FFFFFF", muted: "#9696A7", primary: "#FF4FA3", secondary: "#8C52FF",
    border: "#29293A", header: "#15151F", bubbleMe: "#FF4FA3", bubbleOther: "#20202D",
    input: "#191923", radius: 18, fontSize: 15, shadow: true,
  },
  custom: {
    name: "Custom", background: "#111111", surface: "#1B1B1B", surface2: "#242424",
    text: "#FFFFFF", muted: "#AAAAAA", primary: "#7C5CFF", secondary: "#00D4FF",
    border: "#333333", header: "#1B1B1B", bubbleMe: "#7C5CFF", bubbleOther: "#242424",
    input: "#202020", radius: 14, fontSize: 15, shadow: true,
  },
};

export function createTheme(themeName = "xp", overrides = {}) {
  const base = THEMES[themeName] || THEMES.xp;
  return { ...base, ...overrides, background: overrides.background || base.background, fontSize: overrides.fontSize || base.fontSize };
}
