export const API_CONFIG = {
  // Recommended for Expo: put these in .env as EXPO_PUBLIC_SUPABASE_URL
  // and EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY.
  // You can also paste them here for a private prototype.
  SUPABASE_URL: "",
  SUPABASE_PUBLISHABLE_KEY: "",

  FORCE_LOCAL_MODE: false,
  MAX_USERS: 50,
  REALTIME_ENABLED: true,
};

const envUrl = typeof process !== "undefined" ? process.env?.EXPO_PUBLIC_SUPABASE_URL : "";
const envKey = typeof process !== "undefined" ? process.env?.EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY : "";

export const SUPABASE_URL = envUrl || API_CONFIG.SUPABASE_URL;
export const SUPABASE_PUBLISHABLE_KEY = envKey || API_CONFIG.SUPABASE_PUBLISHABLE_KEY;

export const isBackendConfigured =
  !API_CONFIG.FORCE_LOCAL_MODE &&
  SUPABASE_URL.trim().length > 0 &&
  SUPABASE_PUBLISHABLE_KEY.trim().length > 0;
