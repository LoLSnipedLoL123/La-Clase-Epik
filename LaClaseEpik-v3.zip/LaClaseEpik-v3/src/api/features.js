import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import * as ImagePicker from 'expo-image-picker';
import { Platform } from 'react-native';
import { supabase, isBackendConfigured } from './supabase';
import { Backend } from './backend';

Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowAlert: true, shouldPlaySound: true, shouldSetBadge: true }),
});

export async function registerPushNotifications(userId) {
  if (!isBackendConfigured || !Device.isDevice) return null;
  const { status: existing } = await Notifications.getPermissionsAsync();
  let status = existing;
  if (status !== 'granted') ({ status } = await Notifications.requestPermissionsAsync());
  if (status !== 'granted') return null;
  const token = (await Notifications.getExpoPushTokenAsync()).data;
  await supabase.from('push_tokens').upsert({ user_id: userId, token, platform: Platform.OS }, { onConflict: 'user_id,token' });
  if (Platform.OS === 'android') await Notifications.setNotificationChannelAsync('messages', { name: 'Messages', importance: Notifications.AndroidImportance.HIGH });
  return token;
}

export async function pickMedia() {
  const permission = await ImagePicker.requestMediaLibraryPermissionsAsync();
  if (!permission.granted) throw new Error('Media library permission is required.');
  const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images', 'videos'], quality: 0.85, allowsEditing: false });
  if (result.canceled) return null;
  return result.assets?.[0] || null;
}

export async function uploadMedia(asset, userId) {
  if (!isBackendConfigured) return { localUri: asset.uri, type: asset.type === 'video' ? 'video' : 'image' };
  const ext = asset.fileName?.split('.').pop() || (asset.type === 'video' ? 'mp4' : 'jpg');
  const path = `${userId}/${Date.now()}.${ext}`;
  const arrayBuffer = await fetch(asset.uri).then(r => r.arrayBuffer());
  const { error } = await supabase.storage.from('media').upload(path, arrayBuffer, { contentType: asset.mimeType || (asset.type === 'video' ? 'video/mp4' : 'image/jpeg'), upsert: false });
  if (error) throw error;
  const { data } = supabase.storage.from('media').getPublicUrl(path);
  return { url: data.publicUrl, type: asset.type === 'video' ? 'video' : 'image' };
}

export const Features = {
  async searchUsers(query) {
    if (!query?.trim()) return Backend.getUsers();
    if (!isBackendConfigured) return (await Backend.getUsers()).filter(u => u.username.toLowerCase().includes(query.toLowerCase()));
    const { data, error } = await supabase.from('profiles').select('*').ilike('username', `%${query.trim()}%`).limit(50);
    if (error) throw error;
    return data || [];
  },
  async updateProfile(userId, patch) {
    if (!isBackendConfigured) return Backend.updatePresence(userId, patch.presence || 'Online');
    const { data, error } = await supabase.from('profiles').update(patch).eq('id', userId).select().single();
    if (error) throw error;
    return data;
  },
  async createStory(userId, text, mediaUrl = null, mediaType = null) {
    if (!text?.trim() && !mediaUrl) throw new Error('A story needs text or media.');
    if (!isBackendConfigured) return { id: `local-story-${Date.now()}`, user_id: userId, text: text?.trim() || '', media_url: mediaUrl, media_type: mediaType, expires_at: new Date(Date.now()+86400000).toISOString() };
    const { data, error } = await supabase.from('stories').insert({ user_id: userId, text: text?.trim() || '', media_url: mediaUrl, media_type: mediaType }).select().single();
    if (error) throw error;
    return data;
  },
  async createGroup(name, creatorId, memberIds) {
    if (!isBackendConfigured) return { id: `local-group-${Date.now()}`, name, creator_id: creatorId, member_ids: [creatorId, ...memberIds] };
    const { data: group, error } = await supabase.from('groups').insert({ name, creator_id: creatorId }).select().single();
    if (error) throw error;
    const ids = [...new Set([creatorId, ...memberIds])].map(user_id => ({ group_id: group.id, user_id }));
    const { error: memberError } = await supabase.from('group_members').insert(ids);
    if (memberError) throw memberError;
    return group;
  },
  async getGroups(userId) {
    if (!isBackendConfigured) return [];
    const { data, error } = await supabase.from('group_members').select('group:group_id(id,name,creator_id,created_at)').eq('user_id', userId);
    if (error) throw error;
    return (data || []).map(x => x.group).filter(Boolean);
  },
  async setTyping(userId, isTyping) {
    if (!isBackendConfigured) return;
    await supabase.from('typing_status').upsert({ user_id: userId, is_typing: isTyping, updated_at: new Date().toISOString() }, { onConflict: 'user_id' });
  },
  async getTyping() {
    if (!isBackendConfigured) return [];
    const { data, error } = await supabase.from('typing_status').select('user_id,is_typing,updated_at,profiles:user_id(username)').eq('is_typing', true).gt('updated_at', new Date(Date.now()-10000).toISOString());
    if (error) throw error;
    return data || [];
  },
  async markRead(userId, messageId) {
    if (!isBackendConfigured) return;
    await supabase.from('message_reads').upsert({ user_id: userId, message_id: messageId, read_at: new Date().toISOString() }, { onConflict: 'user_id,message_id' });
  },
  async deleteMessage(messageId, userId) {
    if (!isBackendConfigured) return;
    const { error } = await supabase.from('messages').delete().eq('id', messageId).eq('sender_id', userId);
    if (error) throw error;
  },
  async editMessage(messageId, userId, content) {
    if (!isBackendConfigured) return;
    const { error } = await supabase.from('messages').update({ content: content.trim(), edited_at: new Date().toISOString() }).eq('id', messageId).eq('sender_id', userId);
    if (error) throw error;
  },
  async getAdminData() {
    if (!isBackendConfigured) return null;
    const { data: profiles } = await supabase.from('profiles').select('id,username,presence,role,created_at').order('created_at');
    return { profiles: profiles || [] };
  },
  async setUserRole(adminId, userId, role) {
    if (!isBackendConfigured) throw new Error('Admin controls require Supabase.');
    const { error } = await supabase.from('profiles').update({ role }).eq('id', userId);
    if (error) throw error;
    return adminId;
  },
};
