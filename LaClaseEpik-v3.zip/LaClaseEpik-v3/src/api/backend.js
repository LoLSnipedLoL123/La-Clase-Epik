import AsyncStorage from "@react-native-async-storage/async-storage";
import { supabase, isBackendConfigured } from "./supabase";
import { API_CONFIG } from "./config";

const STORAGE = { USERS: "lce_users", MESSAGES: "lce_messages", CURRENT_USER: "lce_current_user" };
const LOCAL_INITIAL_USERS = [
  { id: "local-alex", username: "Alex", avatar: "🧑‍💻", presence: "Online", created_at: new Date().toISOString() },
  { id: "local-sam", username: "Sam", avatar: "😎", presence: "Idle", created_at: new Date().toISOString() },
];
const LOCAL_INITIAL_MESSAGES = [{
  id: "local-message-1", sender_id: "local-alex", sender_username: "Alex", sender_avatar: "🧑‍💻",
  content: "Welcome to La Clase Epik!", type: "text",
  reactions: { "❤️": 0, "😂": 0, "🔥": 0 }, created_at: new Date().toISOString()
}];

async function getLocal(key, fallback = []) {
  try { const v = await AsyncStorage.getItem(key); return v ? JSON.parse(v) : fallback; }
  catch { return fallback; }
}
async function setLocal(key, value) { await AsyncStorage.setItem(key, JSON.stringify(value)); }
function normalizeUser(u) {
  return { id:u.id, username:u.username, avatar:u.avatar||"🙂", presence:u.presence||"Online", created_at:u.created_at||new Date().toISOString() };
}
function safeUsername(name) { return name.trim().toLowerCase().replace(/[^a-z0-9._-]/g,"").slice(0,32); }
function authEmail(username) { return `${safeUsername(username)}@auth.laclaseepik.invalid`; }

export const Backend = {
  isOnline(){ return isBackendConfigured; },

  async getCurrentSession(){
    if(!isBackendConfigured) return getLocal(STORAGE.CURRENT_USER,null);
    const {data:{session}}=await supabase.auth.getSession(); return session;
  },

  async signUp(username,password){
    const clean=safeUsername(username);
    if(clean.length<3) throw new Error("Username must contain at least 3 letters/numbers.");
    if(password.length<8) throw new Error("Password must be at least 8 characters.");
    if(!isBackendConfigured){
      const users=await getLocal(STORAGE.USERS,LOCAL_INITIAL_USERS);
      if(users.length>=API_CONFIG.MAX_USERS) throw new Error("The private server is full.");
      if(users.some(u=>u.username.toLowerCase()===clean)) throw new Error("That username is already taken.");
      const user=normalizeUser({id:`local-${Date.now()}`,username:clean,avatar:"🙂",presence:"Online"});
      await setLocal(STORAGE.USERS,[...users,user]); await setLocal(STORAGE.CURRENT_USER,user); return user;
    }
    const {data,error}=await supabase.auth.signUp({email:authEmail(clean),password});
    if(error) throw error;
    if(!data.user) throw new Error("Account creation failed.");
    // The DB trigger creates the profile automatically.
    const {data:profile,error:profileError}=await supabase.from("profiles").select("*").eq("id",data.user.id).single();
    if(profileError) throw profileError;
    return normalizeUser(profile);
  },

  async login(username,password){
    const clean=safeUsername(username);
    if(!isBackendConfigured){
      const users=await getLocal(STORAGE.USERS,LOCAL_INITIAL_USERS);
      const user=users.find(u=>u.username.toLowerCase()===clean);
      if(!user) throw new Error("Local preview user not found. Sign up first.");
      await setLocal(STORAGE.CURRENT_USER,user); return user;
    }
    const {data,error}=await supabase.auth.signInWithPassword({email:authEmail(clean),password});
    if(error) throw error;
    const {data:profile,error:pe}=await supabase.from("profiles").select("*").eq("id",data.user.id).single();
    if(pe) throw pe; return normalizeUser(profile);
  },

  async logout(){ if(!isBackendConfigured) return AsyncStorage.removeItem(STORAGE.CURRENT_USER); await supabase.auth.signOut(); },

  async getUsers(){
    if(!isBackendConfigured) return getLocal(STORAGE.USERS,LOCAL_INITIAL_USERS);
    const {data,error}=await supabase.from("profiles").select("*").order("created_at",{ascending:true}).limit(API_CONFIG.MAX_USERS);
    if(error) throw error; return (data||[]).map(normalizeUser);
  },

  async updatePresence(userId,presence){
    if(!isBackendConfigured){
      const users=await this.getUsers(); const updated=users.map(u=>u.id===userId?{...u,presence}:u);
      await setLocal(STORAGE.USERS,updated); const me=updated.find(u=>u.id===userId); await setLocal(STORAGE.CURRENT_USER,me); return me;
    }
    const {data,error}=await supabase.from("profiles").update({presence}).eq("id",userId).select().single();
    if(error) throw error; return normalizeUser(data);
  },

  async getMessages(){
    if(!isBackendConfigured) return getLocal(STORAGE.MESSAGES,LOCAL_INITIAL_MESSAGES);
    const {data,error}=await supabase.from("messages")
      .select("id,sender_id,content,type,reactions,created_at,profiles:sender_id(username,avatar,presence)")
      .order("created_at",{ascending:true}).limit(500);
    if(error) throw error;
    return (data||[]).map(m=>({...m,sender_username:m.profiles?.username||"Unknown",sender_avatar:m.profiles?.avatar||"🙂",presence:m.profiles?.presence||"Invisible"}));
  },

  async sendMessage({senderId,content,type="text"}){
    if(!content?.trim()) return null;
    if(!isBackendConfigured){
      const messages=await this.getMessages(), users=await this.getUsers(), sender=users.find(u=>u.id===senderId);
      const msg={id:`local-message-${Date.now()}`,sender_id:senderId,sender_username:sender?.username||"Unknown",sender_avatar:sender?.avatar||"🙂",
        content:content.trim(),type,reactions:{"❤️":0,"😂":0,"🔥":0},created_at:new Date().toISOString()};
      await setLocal(STORAGE.MESSAGES,[...messages,msg]); return msg;
    }
    const {data,error}=await supabase.from("messages").insert({sender_id:senderId,content:content.trim(),type,reactions:{"❤️":0,"😂":0,"🔥":0}})
      .select("id,sender_id,content,type,reactions,created_at,profiles:sender_id(username,avatar,presence)").single();
    if(error) throw error;
    return {...data,sender_username:data.profiles?.username||"Unknown",sender_avatar:data.profiles?.avatar||"🙂",presence:data.profiles?.presence||"Invisible"};
  },

  async reactToMessage(messageId,emoji){
    if(!isBackendConfigured){
      const messages=await this.getMessages();
      const updated=messages.map(m=>m.id===messageId?{...m,reactions:{...(m.reactions||{}),[emoji]:(m.reactions?.[emoji]||0)+1}}:m);
      await setLocal(STORAGE.MESSAGES,updated); return updated.find(m=>m.id===messageId);
    }
    // Atomic reaction RPC is used in v2 to avoid lost updates from two simultaneous users.
    const {data,error}=await supabase.rpc("increment_message_reaction",{message_id:messageId,reaction:emoji});
    if(error) throw error; return data;
  },

  async getStories(){
    if(!isBackendConfigured) return [
      {id:"story-1",username:"Alex",avatar:"🧑‍💻",text:"School is finished 😎"},
      {id:"story-2",username:"Sam",avatar:"😎",text:"Gaming tonight?"}
    ];
    const {data,error}=await supabase.from("stories").select("id,text,created_at,expires_at,profiles:user_id(username,avatar,presence)")
      .gt("expires_at",new Date().toISOString()).order("created_at",{ascending:false});
    if(error) throw error;
    return (data||[]).map(s=>({...s,username:s.profiles?.username||"Unknown",avatar:s.profiles?.avatar||"🙂",presence:s.profiles?.presence||"Invisible"}));
  },

  subscribeToMessages(callback){
    if(!isBackendConfigured) return {unsubscribe(){}};
    const channel=supabase.channel("lce:messages",{config:{private:true}})
      .on("postgres_changes",{event:"*",schema:"public",table:"messages"},async()=>callback(await this.getMessages()))
      .subscribe();
    return {unsubscribe(){supabase.removeChannel(channel);}};
  },

  subscribeToUsers(callback){
    if(!isBackendConfigured) return {unsubscribe(){}};
    const channel=supabase.channel("lce:profiles",{config:{private:true}})
      .on("postgres_changes",{event:"*",schema:"public",table:"profiles"},async()=>callback(await this.getUsers()))
      .subscribe();
    return {unsubscribe(){supabase.removeChannel(channel);}};
  },

  async seedLocalData(){
    if(await AsyncStorage.getItem(STORAGE.USERS)===null) await setLocal(STORAGE.USERS,LOCAL_INITIAL_USERS);
    if(await AsyncStorage.getItem(STORAGE.MESSAGES)===null) await setLocal(STORAGE.MESSAGES,LOCAL_INITIAL_MESSAGES);
  }
};
