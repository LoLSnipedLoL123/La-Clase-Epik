import React, { useState } from 'react';
import { View, Text, TouchableOpacity, ScrollView, TextInput, StyleSheet, Alert } from 'react-native';
import { createTheme } from '../theme/themes';

export default function SettingsScreen({ themeName, setThemeName, overrides, setOverrides, onBack }) {
  const [bg, setBg] = useState(overrides.background || '');
  const [font, setFont] = useState(String(overrides.fontSize || ''));
  const themes = ['xp', 'pikochat', 'custom'];
  return <ScrollView style={[styles.container,{backgroundColor:themeName==='xp'?theme.background:'#090b14'}]}>
    <View style={[styles.header,{backgroundColor:theme.header}]}><TouchableOpacity onPress={onBack}><Text style={styles.back}>‹</Text></TouchableOpacity><Text style={styles.title}>Settings & Themes</Text></View>
    <Text style={[styles.section,{color:theme.text}]}>Theme</Text>
    <View style={styles.row}>{themes.map(t=><TouchableOpacity key={t} onPress={()=>setThemeName(t)} style={[styles.card,{borderColor:theme.border,backgroundColor:theme.surface},themeName===t&&{borderColor:theme.primary,borderWidth:2}]}><Text style={{fontSize:25}}>{t==='xp'?'🪟':t==='pikochat'?'🌈':'🎨'}</Text><Text style={{color:theme.text,fontWeight:'900',marginTop:6}}>{t==='xp'?'Windows XP':t==='pikochat'?'Pikochat Dark':'Custom'}</Text></TouchableOpacity>)}</View>
    <Text style={[styles.section,{color:theme.text}]}>Custom overrides</Text>
    <TextInput value={bg} onChangeText={setBg} placeholder="#101820" placeholderTextColor={theme.muted} style={[styles.input,{color:theme.text,borderColor:theme.border,backgroundColor:theme.input}]} />
    <TextInput value={font} onChangeText={setFont} keyboardType="numeric" placeholder="Font size (e.g. 16)" placeholderTextColor={theme.muted} style={[styles.input,{color:theme.text,borderColor:theme.border,backgroundColor:theme.input}]} />
    <TouchableOpacity onPress={()=>{const n=Number(font); if(font && (!n||n<10||n>30)) return Alert.alert('Font size','Use 10–30.'); setOverrides({background:bg||null,fontSize:n||null});}} style={[styles.button,{backgroundColor:theme.primary}]}><Text style={styles.buttonText}>Apply customization</Text></TouchableOpacity>
    <Text style={[styles.note,{color:theme.muted}]}>Your private server can use XP, Pikochat or custom HEX/font overrides. Changes apply immediately.</Text>
  </ScrollView>
}
const styles=StyleSheet.create({container:{flex:1},header:{height:64,flexDirection:'row',alignItems:'center',paddingHorizontal:14},back:{color:'#fff',fontSize:38},title:{color:'#fff',fontWeight:'900',fontSize:19,marginLeft:10},section:{fontSize:19,fontWeight:'900',margin:18},row:{flexDirection:'row',gap:10,paddingHorizontal:14},card:{flex:1,padding:14,borderRadius:14,borderWidth:1},input:{marginHorizontal:16,marginBottom:10,padding:13,borderWidth:1,borderRadius:10},button:{margin:16,padding:14,borderRadius:12,alignItems:'center'},buttonText:{color:'#fff',fontWeight:'900'},note:{margin:16,lineHeight:20}})
