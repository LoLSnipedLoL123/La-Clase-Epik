import React, { useState } from "react";
import { View, Text, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform, Alert } from "react-native";
import { Backend } from "../api/backend";

export default function AuthScreen({ theme, onAuthenticated }) {
  const [mode, setMode] = useState("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit() {
    if (!username.trim()) return Alert.alert("Username required", "Enter your username.");
    if (!password) return Alert.alert("Password required", "Enter your password.");
    try {
      setLoading(true);
      const user = mode === "login" ? await Backend.login(username, password) : await Backend.signUp(username, password);
      onAuthenticated(user);
    } catch (error) {
      Alert.alert("Authentication error", error?.message || "Something went wrong.");
    } finally { setLoading(false); }
  }

  return (
    <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={[styles.container, { backgroundColor: theme.background }]}>
      <View style={[styles.card, { backgroundColor: theme.surface, borderColor: theme.border, borderRadius: theme.radius }]}>
        <Text style={[styles.logo, { color: theme.primary }]}>La Clase Epik</Text>
        <Text style={[styles.subtitle, { color: theme.muted }]}>Private friends network</Text>
        <View style={[styles.modeSwitch, { backgroundColor: theme.surface2 }]}>
          {["login", "signup"].map((item) => (
            <TouchableOpacity key={item} onPress={() => setMode(item)} style={[styles.modeButton, mode === item && { backgroundColor: theme.primary }]}>
              <Text style={{ color: mode === item ? "#FFFFFF" : theme.text, fontWeight: "800" }}>{item === "login" ? "Login" : "Sign Up"}</Text>
            </TouchableOpacity>
          ))}
        </View>
        <TextInput value={username} onChangeText={setUsername} placeholder="Username" placeholderTextColor={theme.muted} autoCapitalize="none" style={[styles.input, { backgroundColor: theme.input, color: theme.text, borderColor: theme.border }]} />
        <TextInput value={password} onChangeText={setPassword} placeholder="Password" placeholderTextColor={theme.muted} secureTextEntry autoCapitalize="none" style={[styles.input, { backgroundColor: theme.input, color: theme.text, borderColor: theme.border }]} />
        <TouchableOpacity disabled={loading} onPress={submit} style={[styles.submit, { backgroundColor: theme.primary }]}>
          <Text style={styles.submitText}>{loading ? "Connecting..." : mode === "login" ? "Enter La Clase Epik" : "Create Account"}</Text>
        </TouchableOpacity>
        <Text style={[styles.info, { color: theme.muted }]}>New members are automatically connected to the private network.</Text>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", padding: 20 },
  card: { padding: 22, borderWidth: 1 },
  logo: { fontSize: 30, fontWeight: "900", textAlign: "center" },
  subtitle: { textAlign: "center", marginTop: 5, marginBottom: 22 },
  modeSwitch: { flexDirection: "row", padding: 4, borderRadius: 12, marginBottom: 16 },
  modeButton: { flex: 1, alignItems: "center", paddingVertical: 10, borderRadius: 9 },
  input: { borderWidth: 1, borderRadius: 10, paddingHorizontal: 14, paddingVertical: 13, marginBottom: 11, fontSize: 15 },
  submit: { paddingVertical: 14, borderRadius: 10, alignItems: "center", marginTop: 4 },
  submitText: { color: "#FFFFFF", fontWeight: "900", fontSize: 15 },
  info: { textAlign: "center", marginTop: 16, lineHeight: 19, fontSize: 12 },
});
