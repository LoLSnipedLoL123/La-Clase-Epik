import React from "react";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import StoriesTray from "../components/StoriesTray";

export default function HomeScreen({ theme, currentUser, users, stories, onOpenChat, onOpenProfile }) {
  return (
    <View style={[styles.container, { backgroundColor: theme.background }]}>
      <View style={[styles.header, { backgroundColor: theme.header, borderBottomColor: theme.border }]}>
        <View>
          <Text style={styles.title}>La Clase Epik</Text>
          <Text style={styles.subtitle}>{users.length}/50 connected</Text>
        </View>
        <TouchableOpacity onPress={onOpenProfile}><Text style={styles.profile}>{currentUser?.avatar || "🙂"}</Text></TouchableOpacity>
      </View>

      <StoriesTray stories={stories} theme={theme} onStoryPress={onOpenChat} />

      <View style={styles.body}>
        <Text style={[styles.heading, { color: theme.text }]}>Everyone</Text>
        <Text style={[styles.description, { color: theme.muted }]}>Every member of the private server is automatically connected.</Text>
        <TouchableOpacity onPress={onOpenChat} style={[styles.chatButton, { backgroundColor: theme.primary }]}>
          <Text style={styles.chatText}>Open Messages</Text>
        </TouchableOpacity>

        {users.slice(0, 8).map((user) => (
          <View key={user.id} style={[styles.member, { backgroundColor: theme.surface, borderColor: theme.border }]}>
            <Text style={styles.avatar}>{user.avatar || "🙂"}</Text>
            <View>
              <Text style={[styles.username, { color: theme.text }]}>{user.username}</Text>
              <Text style={[styles.presence, { color: theme.muted }]}>{user.presence}</Text>
            </View>
          </View>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { height: 64, paddingHorizontal: 16, flexDirection: "row", justifyContent: "space-between", alignItems: "center", borderBottomWidth: 1 },
  title: { color: "#FFFFFF", fontWeight: "900", fontSize: 19 },
  subtitle: { color: "#DDDDDD", fontSize: 11, marginTop: 1 },
  profile: { fontSize: 30 },
  body: { padding: 16 },
  heading: { fontSize: 23, fontWeight: "900" },
  description: { marginTop: 5, marginBottom: 15 },
  chatButton: { padding: 14, alignItems: "center", borderRadius: 12, marginBottom: 15 },
  chatText: { color: "#FFFFFF", fontWeight: "900" },
  member: { flexDirection: "row", alignItems: "center", padding: 11, borderWidth: 1, borderRadius: 12, marginBottom: 7 },
  avatar: { fontSize: 27, marginRight: 11 },
  username: { fontWeight: "900", fontSize: 15 },
  presence: { marginTop: 2, fontSize: 12 },
});
