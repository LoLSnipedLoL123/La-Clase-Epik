create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique check (username ~ '^[a-z0-9._-]{3,32}$'),
  avatar text not null default '🙂',
  presence text not null default 'Online' check (presence in ('Online','Idle','DND','Invisible')),
  created_at timestamptz not null default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 2000),
  type text not null default 'text' check (type in ('text','image','video')),
  reactions jsonb not null default '{"❤️":0,"😂":0,"🔥":0}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.stories (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  text text not null check (char_length(text) between 1 and 500),
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '24 hours')
);

create or replace function public.create_profile_for_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
declare
  wanted_username text;
begin
  wanted_username := lower(coalesce(new.raw_user_meta_data->>'username', split_part(new.email,'@',1)));
  if wanted_username !~ '^[a-z0-9._-]{3,32}$' then
    raise exception 'Invalid username';
  end if;
  if (select count(*) from public.profiles) >= 50 then
    raise exception 'Private server is full';
  end if;
  insert into public.profiles(id, username) values(new.id, wanted_username);
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.create_profile_for_new_user();

create or replace function public.increment_message_reaction(message_id uuid, reaction text)
returns public.messages
language plpgsql
security invoker
as $$
declare result public.messages;
begin
  if reaction not in ('❤️','😂','🔥') then raise exception 'Invalid reaction'; end if;
  update public.messages
  set reactions = jsonb_set(reactions, array[reaction], to_jsonb(coalesce((reactions->>reaction)::int,0)+1), true)
  where id=message_id
  returning * into result;
  if result.id is null then raise exception 'Message not found'; end if;
  return result;
end;
$$;

alter table public.profiles enable row level security;
alter table public.messages enable row level security;
alter table public.stories enable row level security;

drop policy if exists "authenticated users can view profiles" on public.profiles;
create policy "authenticated users can view profiles" on public.profiles for select to authenticated using (true);

drop policy if exists "users can update own profile" on public.profiles;
create policy "users can update own profile" on public.profiles for update to authenticated
using (auth.uid()=id) with check (auth.uid()=id);

drop policy if exists "authenticated users can view messages" on public.messages;
create policy "authenticated users can view messages" on public.messages for select to authenticated using (true);

drop policy if exists "users can send messages" on public.messages;
create policy "users can send messages" on public.messages for insert to authenticated
with check (auth.uid()=sender_id);

drop policy if exists "authenticated users can react" on public.messages;
create policy "authenticated users can react" on public.messages for update to authenticated using (true) with check (true);

drop policy if exists "authenticated users can view active stories" on public.stories;
create policy "authenticated users can view active stories" on public.stories for select to authenticated
using (expires_at > now());

drop policy if exists "users can create stories" on public.stories;
create policy "users can create stories" on public.stories for insert to authenticated
with check (auth.uid()=user_id);

grant execute on function public.increment_message_reaction(uuid,text) to authenticated;

-- Database Changes are used by this v2 client.
alter publication supabase_realtime add table public.messages;
alter publication supabase_realtime add table public.profiles;

-- Private Realtime channel authorization.
create policy "lce authenticated receive"
on realtime.messages for select to authenticated
using (topic like 'lce:%');

create policy "lce authenticated send"
on realtime.messages for insert to authenticated
with check (topic like 'lce:%');

-- Optional hardening: do not expose service_role in the mobile app.
-- Keep any service_role key server-side only.

-- v3 feature tables
alter table public.profiles add column if not exists role text not null default 'member' check (role in ('owner','admin','moderator','member'));
alter table public.profiles add column if not exists bio text not null default '';
alter table public.profiles add column if not exists avatar_url text;
alter table public.messages add column if not exists edited_at timestamptz;
alter table public.stories add column if not exists media_url text;
alter table public.stories add column if not exists media_type text;

create table if not exists public.push_tokens (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade,
 token text not null, platform text not null, created_at timestamptz not null default now(), unique(user_id,token)
);
create table if not exists public.typing_status (
 user_id uuid primary key references public.profiles(id) on delete cascade, is_typing boolean not null default false, updated_at timestamptz not null default now()
);
create table if not exists public.message_reads (
 user_id uuid not null references public.profiles(id) on delete cascade, message_id uuid not null references public.messages(id) on delete cascade,
 read_at timestamptz not null default now(), primary key(user_id,message_id)
);
create table if not exists public.groups (
 id uuid primary key default gen_random_uuid(), name text not null check(char_length(name) between 1 and 60), creator_id uuid not null references public.profiles(id), created_at timestamptz not null default now()
);
create table if not exists public.group_members (
 group_id uuid not null references public.groups(id) on delete cascade, user_id uuid not null references public.profiles(id) on delete cascade,
 created_at timestamptz not null default now(), primary key(group_id,user_id)
);

alter table public.push_tokens enable row level security;
alter table public.typing_status enable row level security;
alter table public.message_reads enable row level security;
alter table public.groups enable row level security;
alter table public.group_members enable row level security;

create policy "users manage own push tokens" on public.push_tokens for all to authenticated using(auth.uid()=user_id) with check(auth.uid()=user_id);
create policy "authenticated typing read" on public.typing_status for select to authenticated using(true);
create policy "users manage own typing" on public.typing_status for all to authenticated using(auth.uid()=user_id) with check(auth.uid()=user_id);
create policy "users manage own reads" on public.message_reads for all to authenticated using(auth.uid()=user_id) with check(auth.uid()=user_id);
create policy "members view groups" on public.groups for select to authenticated using(exists(select 1 from public.group_members gm where gm.group_id=id and gm.user_id=auth.uid()));
create policy "users create groups" on public.groups for insert to authenticated with check(auth.uid()=creator_id);
create policy "members view membership" on public.group_members for select to authenticated using(user_id=auth.uid() or exists(select 1 from public.groups g where g.id=group_id and g.creator_id=auth.uid()));
create policy "group creators manage membership" on public.group_members for insert to authenticated with check(exists(select 1 from public.groups g where g.id=group_id and g.creator_id=auth.uid()));

-- Only admins/owners can change roles; users may still update their own non-role profile fields.
drop policy if exists "users can update own profile" on public.profiles;
create policy "users can update own profile" on public.profiles for update to authenticated
using(auth.uid()=id) with check(auth.uid()=id);

-- Realtime for typing and read receipts.
alter publication supabase_realtime add table public.typing_status;
alter publication supabase_realtime add table public.message_reads;
