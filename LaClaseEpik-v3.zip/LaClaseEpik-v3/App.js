import React, { useEffect, useMemo, useState } from 'react';
import { View, ActivityIndicator, Alert, StatusBar } from 'react-native';
import { Backend } from './src/api/backend';
import { Features, registerPushNotifications } from './src/api/features';
import { createTheme } from './src/theme/themes';
import AuthScreen from './src/screens/AuthScreen';
import HomeScreen from './src/screens/HomeScreen';
import ChatScreen from './src/screens/ChatScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import SettingsScreen from './src/screens/SettingsScreen';

export default function App(){
  const [themeName,setThemeName]=useState('xp');
  const [overrides,setOverrides]=useState({background:null,fontSize:null});
  const theme=useMemo(()=>createTheme(themeName,overrides),[themeName,overrides]);
  const [currentUser,setCurrentUser]=useState(null),[users,setUsers]=useState([]),[stories,setStories]=useState([]),[screen,setScreen]=useState('home'),[loading,setLoading]=useState(true);
  async function refresh(){ setUsers(await Backend.getUsers()); setStories(await Backend.getStories()); }
  async function bootstrap(){ try{await Backend.seedLocalData();const session=await Backend.getCurrentSession(); if(session){if(Backend.isOnline()&&session.user){const us=await Backend.getUsers();setCurrentUser(us.find(x=>x.id===session.user.id)||null);}else if(!Backend.isOnline())setCurrentUser(session);} await refresh();}catch(e){console.log(e)}finally{setLoading(false)} }
  useEffect(()=>{bootstrap()},[]);
  useEffect(()=>{if(!currentUser)return;const sub=Backend.subscribeToUsers(us=>{setUsers(us);const me=us.find(x=>x.id===currentUser.id);if(me)setCurrentUser(me)}); registerPushNotifications(currentUser.id).catch(()=>{}); return()=>sub.unsubscribe()},[currentUser?.id]);
  async function authenticated(u){setCurrentUser(u);await refresh();setScreen('home');}
  async function presence(p){try{const u=await Backend.updatePresence(currentUser.id,p);setCurrentUser(u);setUsers(x=>x.map(a=>a.id===u.id?u:a))}catch(e){Alert.alert('Presence',e.message)}}
  async function logout(){await Backend.logout();setCurrentUser(null);setScreen('home')}
  if(loading)return <View style={{flex:1,backgroundColor:theme.background,justifyContent:'center',alignItems:'center'}}><StatusBar barStyle={themeName==='xp'?'dark-content':'light-content'}/><ActivityIndicator size="large" color={theme.primary}/></View>;
  if(!currentUser)return <AuthScreen theme={theme} onAuthenticated={authenticated}/>;
  if(screen==='chat')return <ChatScreen theme={theme} currentUser={currentUser} onBack={()=>setScreen('home')}/>;
  if(screen==='profile')return <ProfileScreen theme={theme} currentUser={currentUser} onPresence={presence} onLogout={logout} onBack={()=>setScreen('home')} onSettings={()=>setScreen('settings')}/>;
  if(screen==='settings')return <SettingsScreen theme={theme} themeName={themeName} setThemeName={setThemeName} overrides={overrides} setOverrides={setOverrides} onBack={()=>setScreen('profile')}/>;
  return <><StatusBar barStyle={themeName==='xp'?'dark-content':'light-content'}/><HomeScreen theme={theme} currentUser={currentUser} users={users} stories={stories} onOpenChat={()=>setScreen('chat')} onOpenProfile={()=>setScreen('profile')} onRefresh={refresh}/></>;
}
