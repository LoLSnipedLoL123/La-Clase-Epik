import React, { useEffect, useState } from "react";
import { View, ActivityIndicator, Alert, StatusBar } from "react-native";
import { Backend } from "./src/api/backend";
import { createTheme } from "./src/theme/themes";
import AuthScreen from "./src/screens/AuthScreen";
import HomeScreen from "./src/screens/HomeScreen";
import ChatScreen from "./src/screens/ChatScreen";
import ProfileScreen from "./src/screens/ProfileScreen";

export default function App() {
  const [themeName] = useState("xp");
  const theme = createTheme(themeName, { background: null, fontSize: null });
  const [currentUser, setCurrentUser] = useState(null);
  const [users, setUsers] = useState([]);
  const [stories, setStories] = useState([]);
  const [screen, setScreen] = useState("home");
  const [loading, setLoading] = useState(true);

  async function bootstrap() {
    try {
      await Backend.seedLocalData();
      const session = await Backend.getCurrentSession();

      if (session) {
        if (Backend.isOnline() && session.user) {
          const allUsers = await Backend.getUsers();
          const user = allUsers.find((item) => item.id === session.user.id);
          if (user) setCurrentUser(user);
        } else if (!Backend.isOnline()) {
          setCurrentUser(session);
        }
      }

      setUsers(await Backend.getUsers());
      setStories(await Backend.getStories());
    } catch (error) {
      console.log("Bootstrap error:", error);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { bootstrap(); }, []);

  useEffect(() => {
    if (!currentUser) return;
    const subscription = Backend.subscribeToUsers((updatedUsers) => {
      setUsers(updatedUsers);
      const me = updatedUsers.find((u) => u.id === currentUser.id);
      if (me) setCurrentUser(me);
    });
    return () => subscription.unsubscribe();
  }, [currentUser?.id]);

  async function authenticated(user) {
    setCurrentUser(user);
    setUsers(await Backend.getUsers());
    setStories(await Backend.getStories());
    setScreen("home");
  }

  async function updatePresence(presence) {
    try {
      const updated = await Backend.updatePresence(currentUser.id, presence);
      setCurrentUser(updated);
      setUsers((old) => old.map((u) => u.id === updated.id ? updated : u));
    } catch (error) {
      Alert.alert("Presence", error?.message || "Could not update presence.");
    }
  }

  async function logout() {
    await Backend.logout();
    setCurrentUser(null);
    setScreen("home");
  }

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: theme.background, justifyContent: "center", alignItems: "center" }}>
        <StatusBar barStyle={themeName === "xp" ? "dark-content" : "light-content"} />
        <ActivityIndicator size="large" color={theme.primary} />
      </View>
    );
  }

  if (!currentUser) {
    return <AuthScreen theme={theme} onAuthenticated={authenticated} />;
  }

  if (screen === "chat") {
    return <ChatScreen theme={theme} currentUser={currentUser} onBack={() => setScreen("home")} />;
  }

  if (screen === "profile") {
    return (
      <ProfileScreen
        theme={theme}
        currentUser={currentUser}
        onPresence={updatePresence}
        onLogout={logout}
        onBack={() => setScreen("home")}
      />
    );
  }

  return (
    <>
      <StatusBar barStyle={themeName === "xp" ? "dark-content" : "light-content"} />
      <HomeScreen
        theme={theme}
        currentUser={currentUser}
        users={users}
        stories={stories}
        onOpenChat={() => setScreen("chat")}
        onOpenProfile={() => setScreen("profile")}
      />
    </>
  );
}
