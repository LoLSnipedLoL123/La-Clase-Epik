# La Clase Epik

Private Expo / React Native friends app for up to 50 users.

## Structure

- `App.js` — application entry point
- `src/api/config.js` — Supabase URL/key configuration
- `src/api/supabase.js` — Supabase client
- `src/api/backend.js` — backend abstraction + local fallback
- `src/theme/themes.js` — XP/Pikochat/custom themes
- `src/components/` — reusable UI
- `src/screens/` — authentication, home, chat and profile screens
- `supabase/schema.sql` — database tables, RLS and Realtime setup

## Setup

```bash
npm install
npx expo start
```

For the real backend:

1. Create a Supabase project.
2. Run `supabase/schema.sql` in the Supabase SQL editor.
3. Put the Supabase project URL and anon key in `src/api/config.js`.
4. Run the Expo project again.

Never put a Supabase `service_role` key in the mobile app.

## Local mode

Leave these blank to use the local AsyncStorage preview:

```js
SUPABASE_URL: "",
SUPABASE_ANON_KEY: "",
```

The UI will continue working without an internet backend.

## Important auth note

This implementation maps usernames to an internal email-style Supabase Auth identity because Supabase Auth natively supports email/password authentication. For a production deployment, a server-side username-auth flow can be added if you want usernames to be handled without exposing the mapping logic in the mobile client.
