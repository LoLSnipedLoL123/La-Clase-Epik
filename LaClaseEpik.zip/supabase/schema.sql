create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique,
  avatar text not null default '🙂',
  presence text not null default 'Online',
  created_at timestamptz not null default now(),
  constraint profiles_presence_check check (presence in ('Online','Idle','DND','Invisible'))
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  sender_id uuid not null references public.profiles(id) on delete cascade,
  content text not null,
  type text not null default 'text',
  reactions jsonb not null default '{"❤️":0,"😂":0,"🔥":0}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.stories (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  text text not null,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null default (now() + interval '24 hours')
);

alter table public.profiles enable row level security;
alter table public.messages enable row level security;
alter table public.stories enable row level security;

create policy "Authenticated users can view profiles"
on public.profiles for select to authenticated using (true);

create policy "Authenticated users can update their own profile"
on public.profiles for update to authenticated
using (auth.uid() = id) with check (auth.uid() = id);

create policy "Authenticated users can view messages"
on public.messages for select to authenticated using (true);

create policy "Authenticated users can send messages"
on public.messages for insert to authenticated
with check (auth.uid() = sender_id);

create policy "Authenticated users can update reactions"
on public.messages for update to authenticated
using (true) with check (true);

create policy "Authenticated users can view active stories"
on public.stories for select to authenticated
using (expires_at > now());

create policy "Authenticated users can create stories"
on public.stories for insert to authenticated
with check (auth.uid() = user_id);

alter publication supabase_realtime add table public.messages;
alter publication supabase_realtime add table public.profiles;
