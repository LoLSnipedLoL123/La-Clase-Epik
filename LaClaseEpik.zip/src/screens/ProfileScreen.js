import React from "react";
import { View, Text, TouchableOpacity, StyleSheet, ScrollView } from "react-native";
import Avatar from "../components/Avatar";

const PRESENCES = [
  { id: "Online", emoji: "🟢", description: "Available to chat" },
  { id: "Idle", emoji: "🟡", description: "Away for a little while" },
  { id: "DND", emoji: "🔴", description: "Do not disturb" },
  { id: "Invisible", emoji: "⚫", description: "Appear offline" },
];

export default function ProfileScreen({ theme, currentUser, onPresence, onLogout, onBack }) {
  return (
    <ScrollView style={[styles.container, { backgroundColor: theme.background }]}>
      <View style={[styles.header, { backgroundColor: theme.header }]}>
        <TouchableOpacity onPress={onBack}><Text style={styles.back}>‹</Text></TouchableOpacity>
        <Text style={styles.title}>Profile</Text>
      </View>

      <View style={styles.profile}>
        <Avatar user={currentUser} size={90} />
        <Text style={[styles.username, { color: theme.text }]}>{currentUser.username}</Text>
        <Text style={[styles.status, { color: theme.muted }]}>{currentUser.presence}</Text>
      </View>

      <Text style={[styles.sectionTitle, { color: theme.text }]}>Presence</Text>

      <View style={styles.presences}>
        {PRESENCES.map((presence) => {
          const active = currentUser.presence === presence.id;
          return (
            <TouchableOpacity
              key={presence.id}
              onPress={() => onPresence(presence.id)}
              style={[styles.presence, { backgroundColor: active ? theme.primary : theme.surface, borderColor: theme.border }]}
            >
              <Text style={styles.presenceEmoji}>{presence.emoji}</Text>
              <View style={{ flex: 1 }}>
                <Text style={[styles.presenceName, { color: active ? "#FFFFFF" : theme.text }]}>{presence.id}</Text>
                <Text style={[styles.presenceDescription, { color: active ? "#EEEEEE" : theme.muted }]}>{presence.description}</Text>
              </View>
              {active && <Text style={styles.check}>✓</Text>}
            </TouchableOpacity>
          );
        })}
      </View>

      <TouchableOpacity onPress={onLogout} style={[styles.logout, { borderColor: theme.border }]}>
        <Text style={[styles.logoutText, { color: theme.text }]}>Log Out</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { height: 64, flexDirection: "row", alignItems: "center", paddingHorizontal: 14 },
  back: { color: "#FFFFFF", fontSize: 38 },
  title: { color: "#FFFFFF", fontSize: 19, fontWeight: "900", marginLeft: 10 },
  profile: { alignItems: "center", paddingVertical: 28 },
  username: { fontSize: 24, fontWeight: "900", marginTop: 12 },
  status: { marginTop: 3 },
  sectionTitle: { fontSize: 18, fontWeight: "900", marginHorizontal: 16, marginBottom: 10 },
  presences: { paddingHorizontal: 12 },
  presence: { flexDirection: "row", alignItems: "center", padding: 13, borderWidth: 1, borderRadius: 12, marginBottom: 8 },
  presenceEmoji: { fontSize: 22, marginRight: 12 },
  presenceName: { fontSize: 15, fontWeight: "900" },
  presenceDescription: { fontSize: 12, marginTop: 2 },
  check: { color: "#FFFFFF", fontWeight: "900", fontSize: 18 },
  logout: { margin: 16, padding: 14, borderWidth: 1, borderRadius: 10, alignItems: "center" },
  logoutText: { fontWeight: "900" },
});
