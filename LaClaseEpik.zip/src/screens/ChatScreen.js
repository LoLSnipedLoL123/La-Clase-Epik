import React, { useEffect, useRef, useState } from "react";
import { View, Text, TextInput, TouchableOpacity, FlatList, KeyboardAvoidingView, Platform, StyleSheet, Alert } from "react-native";
import { Backend } from "../api/backend";
import MessageBubble from "../components/MessageBubble";

export default function ChatScreen({ theme, currentUser, onBack }) {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");
  const listRef = useRef(null);

  async function loadMessages() {
    try { setMessages(await Backend.getMessages()); }
    catch (error) { Alert.alert("Messages", error?.message || "Unable to load messages."); }
  }

  useEffect(() => {
    loadMessages();
    const subscription = Backend.subscribeToMessages(setMessages);
    return () => subscription.unsubscribe();
  }, []);

  async function send() {
    const clean = text.trim();
    if (!clean) return;
    setText("");
    try {
      await Backend.sendMessage({ senderId: currentUser.id, content: clean, type: "text" });
      if (!Backend.isOnline()) await loadMessages();
      setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);
    } catch (error) {
      setText(clean);
      Alert.alert("Send failed", error?.message || "Could not send message.");
    }
  }

  async function react(messageId, emoji) {
    try {
      await Backend.reactToMessage(messageId, emoji);
      if (!Backend.isOnline()) await loadMessages();
    } catch (error) { Alert.alert("Reaction failed", error?.message || "Could not react."); }
  }

  return (
    <KeyboardAvoidingView style={[styles.container, { backgroundColor: theme.background }]} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <View style={[styles.header, { backgroundColor: theme.header, borderBottomColor: theme.border }]}>
        <TouchableOpacity onPress={onBack}><Text style={styles.back}>‹</Text></TouchableOpacity>
        <View style={styles.headerCenter}><Text style={styles.headerTitle}>Messages</Text><Text style={styles.headerStatus}>Private server</Text></View>
        <Text style={styles.serverIcon}>💬</Text>
      </View>

      <FlatList
        ref={listRef}
        data={messages}
        keyExtractor={(item) => String(item.id)}
        renderItem={({ item }) => <MessageBubble message={item} currentUserId={currentUser.id} theme={theme} onReaction={react} />}
        contentContainerStyle={styles.messages}
        onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: false })}
        ListEmptyComponent={<Text style={[styles.empty, { color: theme.muted }]}>No messages yet. Start the conversation.</Text>}
      />

      <View style={[styles.composer, { backgroundColor: theme.surface, borderTopColor: theme.border }]}>
        <TextInput
          value={text}
          onChangeText={setText}
          placeholder="Message everyone..."
          placeholderTextColor={theme.muted}
          style={[styles.input, { backgroundColor: theme.input, color: theme.text, borderColor: theme.border, borderRadius: theme.radius }]}
          multiline maxLength={2000} onSubmitEditing={send}
        />
        <TouchableOpacity onPress={send} style={[styles.send, { backgroundColor: theme.primary }]}><Text style={styles.sendText}>➤</Text></TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: { height: 64, flexDirection: "row", alignItems: "center", paddingHorizontal: 13, borderBottomWidth: 1 },
  back: { color: "#FFFFFF", fontSize: 38, lineHeight: 38 },
  headerCenter: { flex: 1, marginLeft: 8 },
  headerTitle: { color: "#FFFFFF", fontSize: 17, fontWeight: "900" },
  headerStatus: { color: "#DDDDDD", fontSize: 11, marginTop: 1 },
  serverIcon: { fontSize: 25 },
  messages: { paddingVertical: 12, paddingBottom: 20 },
  empty: { textAlign: "center", padding: 30 },
  composer: { flexDirection: "row", alignItems: "flex-end", padding: 9, borderTopWidth: 1 },
  input: { flex: 1, minHeight: 44, maxHeight: 110, paddingHorizontal: 13, paddingVertical: 10, borderWidth: 1, fontSize: 15 },
  send: { width: 45, height: 45, borderRadius: 23, marginLeft: 7, justifyContent: "center", alignItems: "center" },
  sendText: { color: "#FFFFFF", fontSize: 20, fontWeight: "900" },
});
