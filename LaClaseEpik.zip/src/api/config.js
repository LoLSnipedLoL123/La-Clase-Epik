export const API_CONFIG = {
  // Paste values from your Supabase project.
  SUPABASE_URL: "",
  SUPABASE_ANON_KEY: "",

  // Set true to force local preview even when credentials exist.
  FORCE_LOCAL_MODE: false,

  MAX_USERS: 50,
  REALTIME_ENABLED: true,
};

export const isBackendConfigured =
  !API_CONFIG.FORCE_LOCAL_MODE &&
  API_CONFIG.SUPABASE_URL.trim().length > 0 &&
  API_CONFIG.SUPABASE_ANON_KEY.trim().length > 0;
